import React from 'react'
import './App.css'
import logo from '/logo.png'

function App() {
  return (
    <div className="app">
      <img src={logo} alt="Amaya Logo" style={{ width: 120 }} />
      <h1>Welcome to Amaya</h1>
      <p>Connecting brands with buyers</p>
    </div>
  )
}

export default App
