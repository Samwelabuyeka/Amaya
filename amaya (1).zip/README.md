# Amaya

**Amaya** is a modern digital marketing platform that connects brands with buyers through a clean, fast, and responsive web interface.

## 🌐 Live Demo

[https://amaya.vercel.app](https://amaya.vercel.app) *(Add your live link after Vercel deployment)*

## 📦 Features

- 🔥 Built with Vite + React
- 📱 Mobile-responsive UI
- 🎨 Branded with Amaya's custom purple-gradient logo
- 🚀 Ready for deployment on Vercel
- 📁 Includes Android APK for cross-platform access

## 🛠️ Getting Started

```bash
git clone https://github.com/YOUR_USERNAME/amaya.git
cd amaya
npm install
npm run dev
```

## 🧾 License

Licensed to Abuyeka Samwel Andanje, © 2025.
