function App() {
  return (
    <div style={{
      display: 'grid',
      placeItems: 'center',
      height: '100vh',
      fontFamily: 'Arial, sans-serif',
      background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
      color: 'white'
    }}>
      <div>
        <img src="/logo.png" alt="Amaya Logo" style={{ width: '150px', marginBottom: '20px' }} />
        <h1>Welcome to Amaya</h1>
        <p>Your digital marketplace platform</p>
      </div>
    </div>
  )
}

export default App
